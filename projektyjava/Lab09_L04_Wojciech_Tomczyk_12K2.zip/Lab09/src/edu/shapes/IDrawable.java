package edu.shapes;

import java.awt.*;

public interface IDrawable{
    void draw(Graphics graphics, boolean selected);
}


