package edu.shapes;

public interface ISelectable{
    boolean select(int xk, int yk);
}
