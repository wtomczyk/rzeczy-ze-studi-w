package edu.shapes;

public interface IShape extends IDrawable, IMovable, ISelectable{
}
